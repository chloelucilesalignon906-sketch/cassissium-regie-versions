## Régie Cassissium

Pilote la Régie Cassissium depuis Companion : un bouton par langue (lance film, son et séquence lumière), Arrêt, Pause, scènes lumière, allumage et extinction du vidéoprojecteur avec le décompte affiché sur la touche.

**Réglages de la connexion**
- **Adresse de la régie** : `127.0.0.1` si Companion tourne sur l'ordinateur de régie. Sinon l'adresse IP de l'ordinateur de régie (et, dans la régie, Réglages › Stream Deck › « Accepter les ordres du réseau »).
- **Port** : 8787 (celui de Réglages › Stream Deck dans la régie).

**Boutons tout prêts** : onglet *Presets* › Cassissium : glisser les boutons sur la page.

Les touches de langue s'allument en vert pendant la séance de cette langue. Les touches du vidéoprojecteur affichent le décompte (ex. « ON 1:47 »).

**Son de la salle (régie 0.6.1 ou plus récente)**
- Presets › Cassissium › *Son : molettes* : une molette par réglage (volume général, dialogues, caisson de basses, façade, ambiance). Tourner = monter / baisser de 2 %. Appuyer sur la molette du volume = couper / rétablir le son ; sur les autres = revenir à 100 %.
- Le volume général va de 0 à 100 %, les autres de 0 à 150 %. Les touches deviennent orange quand un réglage n'est pas à 100 %, rouges quand le son est coupé.
- Actions : *Son : régler un volume* (monter, baisser, valeur, 100 %) et *Son : couper / rétablir*.
