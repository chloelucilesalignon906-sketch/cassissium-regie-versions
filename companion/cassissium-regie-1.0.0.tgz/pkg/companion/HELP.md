## Régie Cassissium

Pilote la Régie Cassissium depuis Companion : un bouton par langue (lance film, son et séquence lumière), Arrêt, Pause, scènes lumière, allumage et extinction du vidéoprojecteur avec le décompte affiché sur la touche.

**Réglages de la connexion**
- **Adresse de la régie** : `127.0.0.1` si Companion tourne sur l'ordinateur de régie. Sinon l'adresse IP de l'ordinateur de régie (et, dans la régie, Réglages › Stream Deck › « Accepter les ordres du réseau »).
- **Port** : 8787 (celui de Réglages › Stream Deck dans la régie).

**Boutons tout prêts** : onglet *Presets* › Cassissium : glisser les boutons sur la page.

Les touches de langue s'allument en vert pendant la séance de cette langue. Les touches du vidéoprojecteur affichent le décompte (ex. « ON 1:47 »).
